package com.example.alfie_s_app;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class DetailedDisplay extends AppCompatActivity {

    Button edit;
    Button delete;

    TextView name;
    TextView building;
    TextView room;
    TextView time;
    TextView desc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_detail);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        edit = findViewById(R.id.edit_button);
        delete = findViewById(R.id.delete_button);

        name = findViewById(R.id.cal_list_name);
        building = findViewById(R.id.cal_list_building);
        room = findViewById(R.id.cal_list_room);
        time = findViewById(R.id.cal_list_time);
        desc = findViewById(R.id.cal_list_desc);

        //Test Getting that Passed Value
        String passValue;

        //Sets HomeIntent Equal to Intent Passed by Calling Procedure
        Intent homeIntent = getIntent();

        //Set String Equal to Passed Value
        passValue = homeIntent.getStringExtra("pass");

        //Set TextView to Passed Value
        name.setText(passValue);

        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v1) {
                Intent intent = new Intent(getApplicationContext(), EditDetailed.class);
                startActivity(intent);
                //how are we transferring/getting data??

            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v2) {

                //imma delete stuff here.... somehow
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu );

        //make sure menu buttons are properly visible
        MenuItem homeMenu, notifMenu;
        homeMenu = menu.findItem(R.id.home);
        notifMenu = menu.findItem(R.id.no_settings);
        homeMenu.setVisible(true);
        notifMenu.setVisible(true);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        switch (id) {
            case R.id.home:
                Intent intentHome = new Intent(getApplicationContext(), HomePage.class);
                startActivity(intentHome);
                return true;
            case R.id.no_settings:
                Intent intentNotif = new Intent(getApplicationContext(), NotificationSettings.class);
                startActivity(intentNotif);
                return true;
            case R.id.ad_event:
                Intent intentAdd = new Intent(getApplicationContext(), AddEvent.class);
                startActivity(intentAdd);
                return true;
            case R.id.ad_login:
                Intent intentLogin = new Intent(getApplicationContext(), AdminLogin.class);
                startActivity(intentLogin);
                return true;
            case R.id.log_out:
                Intent intentLogout = new Intent(getApplicationContext(), AdminLogout.class);
                startActivity(intentLogout);
                return true;
        }

        return super.onOptionsItemSelected(item);
    }
}