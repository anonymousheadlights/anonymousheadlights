package com.example.alfie_s_app;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.EditText;
import android.os.Bundle;
import android.widget.Toast;

public class AdminLogin extends AppCompatActivity {

    static final String USERNAME = "administrator";
    static final String PASSWORD = "d33r1nh3@dl1gh+5";

    Button loginBut;
    TextView userTitle;
    EditText userInput;
    TextView pwrdTitle;
    EditText pwrdInput;

    Menu globalMenu;

    //static Button editButton, delButton;
    static MenuItem addButton, login, logout;

    Button editButton = findViewById(R.id.edit_button);
    Button delButton = findViewById(R.id.delete_button);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_login);

        //set up toolbar
        Toolbar toolbar = findViewById(R.id.admin_page_toolbar);
        setSupportActionBar(toolbar);

        //set global references for changes in visibility
        Button editButton = findViewById(R.id.edit_button);
        Button delButton = findViewById(R.id.delete_button);


        //create a reference to TextViews, EditTexts, and Buttons
        loginBut = (Button) findViewById(R.id.login_but);
        userTitle = (TextView) findViewById(R.id.user_title);
        userInput = (EditText) findViewById(R.id.user_input);
        pwrdTitle = (TextView) findViewById(R.id.pwrd_title);
        pwrdInput = (EditText) findViewById(R.id.pwrd_input);

        loginBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkCred(userInput.getText().toString(), pwrdInput.getText().toString())){
                    //make edit/delete buttons and add event menu item visible
                    setAdminVisible(true);

                    //go to home page
                    Intent intent = new Intent(getApplicationContext(), HomePage.class);
                    startActivity(intent);

                } else {
                    //return toast if login fails
                    Context context = getApplicationContext();
                    CharSequence text = "Login Failed";
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                }
            }
        });
    }
    //make the edit/delete buttons and the add event menu item visible
    protected void setAdminVisible(boolean tf){
        if (tf) {
            editButton.setVisibility(View.VISIBLE);
            delButton.setVisibility(View.VISIBLE);
        } else {
            editButton.setVisibility(View.GONE);
            delButton.setVisibility(View.GONE);
        }
        addButton.setVisible(tf);
        login.setVisible(!tf);
        logout.setVisible(tf);
    }

    //verify login info
    boolean checkCred(String user, String pass) {
        return (user.equals(USERNAME) && pass.equals(PASSWORD));
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);

        globalMenu = menu;

        //make sure menu buttons are properly visible
        MenuItem homeMenu, notifMenu;
        homeMenu = menu.findItem(R.id.home);
        notifMenu = menu.findItem(R.id.no_settings);
        homeMenu.setVisible(true);
        notifMenu.setVisible(true);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        switch (id) {
            case R.id.home:
                Intent intentHome = new Intent(getApplicationContext(), HomePage.class);
                startActivity(intentHome);
                return true;
            case R.id.no_settings:
                Intent intentNotif = new Intent(getApplicationContext(), NotificationSettings.class);
                startActivity(intentNotif);
                return true;
            case R.id.ad_event:
                Intent intentAdd = new Intent(getApplicationContext(), AddEvent.class);
                startActivity(intentAdd);
                return true;
            case R.id.ad_login:
                Intent intentLogin = new Intent(getApplicationContext(), AdminLogin.class);
                startActivity(intentLogin);
                return true;
            case R.id.log_out:
                Intent intentLogout = new Intent(getApplicationContext(), AdminLogout.class);
                startActivity(intentLogout);
                return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
