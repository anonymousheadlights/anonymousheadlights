package com.example.alfie_s_app;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.EditText;
import android.os.Bundle;
import android.widget.Toast;

public class AdminLogout extends AppCompatActivity {

    Menu globalMenu;

    //static Button editButton, delButton;
    static MenuItem addButton, login, logout;

    Button editButton = findViewById(R.id.edit_button);
    Button delButton = findViewById(R.id.delete_button);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //set global references for changes in visibility
        Button editButton = findViewById(R.id.edit_button);
        Button delButton = findViewById(R.id.delete_button);

        editButton.setVisibility(View.GONE);
        delButton.setVisibility(View.GONE);

        addButton.setVisible(false);
        login.setVisible(true);
        logout.setVisible(false);

        Intent intent = new Intent(getApplicationContext(), HomePage.class);
        startActivity(intent);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);

        globalMenu = menu;

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        switch (id) {
            default:
        }

        return super.onOptionsItemSelected(item);
    }
}
