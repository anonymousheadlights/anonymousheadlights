package com.example.alfie_s_app;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentReference;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;


public class AddEvent extends AppCompatActivity {

    String name, room, building, description, time;
    Button save;
    Context context;

    //database
    DatabaseReference db = FirebaseDatabase.getInstance().getReference();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_detailed);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        context = this;

        //converts text inputs into strings
        name = ((EditText) findViewById(R.id.cal_list_name)).getText().toString();
        building = ((EditText) findViewById(R.id.cal_list_building)).getText().toString();
        room = ((EditText) findViewById(R.id.cal_list_room)).getText().toString();
        time = ((EditText) findViewById(R.id.cal_list_time)).getText().toString();
        description = ((EditText) findViewById(R.id.cal_list_desc)).getText().toString();

        Button save = (Button) findViewById(R.id.save_button);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submit(v);
            }
        });


    }

    public void submit (View view) {
        newEntry(name, building, room, time, description);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);

        //make sure menu buttons are properly visible
        MenuItem homeMenu, notifMenu;
        homeMenu = menu.findItem(R.id.home);
        notifMenu = menu.findItem(R.id.no_settings);
        homeMenu.setVisible(true);
        notifMenu.setVisible(true);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        switch (id) {
            case R.id.home:
                Intent intentHome = new Intent(getApplicationContext(), HomePage.class);
                startActivity(intentHome);
                return true;
            case R.id.no_settings:
                Intent intentNotif = new Intent(getApplicationContext(), NotificationSettings.class);
                startActivity(intentNotif);
                return true;
            case R.id.ad_event:
                Intent intentAdd = new Intent(getApplicationContext(), AddEvent.class);
                startActivity(intentAdd);
                return true;
            case R.id.ad_login:
                Intent intentLogin = new Intent(getApplicationContext(), AdminLogin.class);
                startActivity(intentLogin);
                return true;
            case R.id.log_out:
                Intent intentLogout = new Intent(getApplicationContext(), AdminLogout.class);
                startActivity(intentLogout);
                return true;
        }

        return super.onOptionsItemSelected(item);
    }

    //puts it into database
    private void newEntry(String name, String building, String room, String time,
                          String description) {
        Event event = new Event(name, building, room, time, description);

        db.child("Events").child("testing").setValue(event);
    }
}

