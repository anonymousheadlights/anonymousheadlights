package com.example.alfie_s_app;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CalendarView;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.LinkedList;

public class CalendarButton extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.full_calendar);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        CalendarView calendar = (CalendarView) findViewById(R.id.calendar);
        ListView calList = (ListView) findViewById(R.id.calendar_list);
        final ArrayList<String> list = new ArrayList<>();
        final ArrayAdapter<String> adapt = new ArrayAdapter<>(getApplicationContext(),
            R.layout.calendar_list_item, list);
        final ListView listView = findViewById(android.R.id.list);

        calendar.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view,
                                            int year, int month, int dayOfMonth) {
                //get events from DayEvent somewhere
                ArrayList<Event> dayList = new ArrayList<>();
                Event event;
                int n = dayList.size();

                String nameList[], buildingList[], roomList[], timeList[];
                nameList = new String[n];
                buildingList = new String[n];
                roomList = new String[n];
                timeList = new String[n];

                if (n != 0) {

                    for (int i = 0; i < n; i++) {
                        event = dayList.get(i);

                        //put strings into arrayList
                        nameList[i] = event.getName();
                        buildingList[i] = event.getBuilding();
                        roomList[i] = event.getRoom();
                        timeList[i] = event.getTime();
                    }

                    CustomAdapter customAdapter = new CustomAdapter(getApplicationContext(),
                            nameList, buildingList, roomList, timeList);
                    //set format view
                    listView.setAdapter(customAdapter);
                } else {
                    //listView.setEmptyView(emptyView);
                }
            }
        });

        //show toast on item click
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id){
                Intent intent = new Intent(getApplicationContext(), DetailedDisplay.class);
                startActivity(intent);
            }
        });

        //set format view
        //listView.setAdapter(adapt);
        //listView.setEmptyView(emptyView);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);

        //make sure menu buttons are properly visible
        MenuItem homeMenu, notifMenu;
        homeMenu = menu.findItem(R.id.home);
        notifMenu = menu.findItem(R.id.no_settings);
        homeMenu.setVisible(true);
        notifMenu.setVisible(true);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        switch (id) {
            case R.id.home:
                Intent intentHome = new Intent(getApplicationContext(), HomePage.class);
                startActivity(intentHome);
                return true;
            case R.id.no_settings:
                Intent intentNotif = new Intent(getApplicationContext(), NotificationSettings.class);
                startActivity(intentNotif);
                return true;
            case R.id.ad_event:
                Intent intentAdd = new Intent(getApplicationContext(), AddEvent.class);
                startActivity(intentAdd);
                return true;
            case R.id.ad_login:
                Intent intentLogin = new Intent(getApplicationContext(), AdminLogin.class);
                startActivity(intentLogin);
                return true;
            case R.id.log_out:
                Intent intentLogout = new Intent(getApplicationContext(), AdminLogout.class);
                startActivity(intentLogout);
                return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
