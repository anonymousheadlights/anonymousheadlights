package com.example.alfie_s_app;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class CustomAdapter extends BaseAdapter {
    Context context;
    String nameList[], buildingList[], roomList[], timeList[];
    LayoutInflater inflater;

    public CustomAdapter(Context appContext, String name[], String building[], String room[],
                         String time[]){
        context = appContext;
        nameList = name;
        buildingList = building;
        roomList = room;
        timeList = time;
        inflater = (LayoutInflater.from(appContext));
    }

    @Override
    public int getCount() {
        return nameList.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }
    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view = inflater.inflate(R.layout.full_calendar, null);
        TextView name, building, room, time;
        name = view.findViewById(R.id.cal_list_name);
        building = view.findViewById(R.id.cal_list_building);
        room = view.findViewById(R.id.cal_list_room);
        time = view.findViewById(R.id.cal_list_time);

        name.setText(nameList[i]);
        building.setText(buildingList[i]);
        room.setText(roomList[i]);
        time.setText(timeList[i]);
        return view;
    }



}
